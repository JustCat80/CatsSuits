# Cat's Suits
A More Suits Pack I made for me and some friends

If there are issues, please create an issue or pull request on the [Github Page](https://github.com/JustCat80/CatsSuits)

# Changelog
- 1.1.1
    Add Grey (Template) Suit
    Add Hero's Suit
- 1.0.0
    Bam